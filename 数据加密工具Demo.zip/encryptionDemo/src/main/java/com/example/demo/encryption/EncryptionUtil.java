package com.example.demo.encryption;

import cfca.sadk.algorithm.sm2.SM2PrivateKey;
import cfca.sadk.algorithm.sm2.SM2PublicKey;
import cfca.sadk.cgb.toolkit.SM2Toolkit;
import cfca.sadk.cgb.toolkit.SM4Toolkit;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.Map;
import java.util.TreeMap;

/**
 * 加密解密方法
 * @author shiBw
 */
public class EncryptionUtil {
    private static SecureRandom random = new SecureRandom();
    private static SM2Toolkit sm2Toolkit = new SM2Toolkit();
    private static String KEY_SIGNATURE = "signature";
    private static String KEY_SECRET = "secret";
    private static String KEY_DATA = "data";

    //senderPublicKey--接受者的公钥 receiverPrivateKey--发送者的私钥
    //客户端用此方法 --用服务端公钥加密，用客户端私钥加签
    public static JSONObject EncryptAndSign(JSONObject src, SM2PublicKey receiverPublicKey, SM2PrivateKey senderPrivateKey) throws Exception {
        // 生成随机密钥
        byte[] key = new byte[16];
        random.nextBytes(key);
        JSONObject data = src.getJSONObject(KEY_DATA);
        if (data == null) {
            throw new Exception("Can not find 'data' in object");
        }
        JSONObject dest = (JSONObject) src.clone();

        // SM4 对称加密
        SM4Toolkit sm4Toolkit = new SM4Toolkit();
        sm4Toolkit.SM4Init(key, key);
        byte[] encData = sm4Toolkit.SM4EncryptData(data.toJSONString().getBytes());

        dest.put(KEY_DATA, Base64.getEncoder().encodeToString(encData));
        // 使用 SM2 加密对称密钥
        dest.put(KEY_SECRET, Base64.getEncoder().encodeToString(sm2Toolkit.SM2EncryptData(receiverPublicKey, key)));

        // 使用 SM2 进行签名
        dest.put(KEY_SIGNATURE, Base64.getEncoder().encodeToString(sm2Toolkit.SM2Sign(senderPrivateKey, SerializeObject(dest).getBytes())));
        return dest;
    }

    //senderPublicKey--发送者的公钥 receiverPrivateKey--接收者的私钥
    //服务端用此方法 --用客户端公钥验签，用服务端私钥解密
    public static JSONObject VerifyAndDecrypt(JSONObject src, SM2PublicKey senderPublicKey, SM2PrivateKey receiverPrivateKey) throws Exception {
        JSONObject dest = (JSONObject) src.clone();
        byte[] signature = dest.getBytes(KEY_SIGNATURE);
        dest.remove(KEY_SIGNATURE);
        // 验证签名
        if (!sm2Toolkit.SM2Verify(senderPublicKey, SerializeObject(dest).getBytes(), signature)) {
            throw new Exception("The signature is not valid!");
        }

        // 解密报文
        byte[] secret = dest.getBytes(KEY_SECRET);
        dest.remove(KEY_SECRET);

        byte[] data = dest.getBytes(KEY_DATA);
        byte[] sm4Key = sm2Toolkit.SM2DecryptData(receiverPrivateKey, secret);

        SM4Toolkit sm4Toolkit = new SM4Toolkit();
        sm4Toolkit.SM4Init(sm4Key, sm4Key);
        byte[] json = sm4Toolkit.SM4DecryptData(data);
//        String res = new String(json,"UTF-8");
        dest.put(KEY_DATA, JSON.parse(json));
        return dest;
    }

    private static String SerializeObject(JSONObject object) {
        JSONObject dest = new JSONObject(new TreeMap<>(object));

        StringBuilder builder = new StringBuilder();
        for (Map.Entry<String, Object> entry : dest.entrySet()) {
            builder.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
        }
        builder.replace(builder.length() - 1, builder.length(), "");
        return builder.toString();
    }
}
