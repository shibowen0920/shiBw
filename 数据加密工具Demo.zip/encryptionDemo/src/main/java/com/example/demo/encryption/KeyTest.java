package com.example.demo.encryption;

import cfca.sadk.algorithm.sm2.SM2PrivateKey;
import cfca.sadk.algorithm.sm2.SM2PublicKey;
import cfca.sadk.org.bouncycastle.util.encoders.Hex;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;

import java.math.BigInteger;

/**
 * 生成秘钥测试类
 *
 * @author shiBw
 */
public class KeyTest {
    public static void main(String[] args) {
        JSONObject param = new JSONObject();
        param.put("appID", "citic");
        param.put("funcName", "project");
        JSONArray data1 = new JSONArray();
        JSONObject data = new JSONObject();
        JSONObject data2 = new JSONObject();
        data.put("userId", "1");
        data.put("userNo", "001");
        data.put("userName", "测试用户");
        data1.add(data);
        data2.put("list", data1);
        param.put("data", data2);
        String publicKey = "3059301306072a8648ce3d020106082a811ccf5501822d03420004a307fe4177d7c599e9b07524afba66c51f82aa34ec4285107ce6c9690453ca774da89b6e9c91ddf2c86a4887b70b80bb475d58707cf3ae4a22d579bb1bbf3a57";
        String privateKey = "7ed494a8906de50cb4437420ba3f56c819eab8f9f9783d8de16ea6a2cb4a6610";

        SM2PublicKey pub = new SM2PublicKey(Hex.decode(publicKey));
        SM2PrivateKey priv = new SM2PrivateKey(new BigInteger(1, Hex.decode(privateKey)), pub.getPubX_Int(), pub.getPubYByInt());

        System.out.println("加密前:");
        System.out.println(JSON.toJSONString(param, SerializerFeature.PrettyFormat));

        JSONObject dest = new JSONObject();

        try {
            System.out.println("加密后:");
            dest = EncryptionUtil.EncryptAndSign(param, pub, priv);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(JSON.toJSONString(dest, SerializerFeature.PrettyFormat));

        System.out.println("还原后:");
        try {
            JSONObject src = EncryptionUtil.VerifyAndDecrypt(dest, pub, priv);
            System.out.println(JSON.toJSONString(src, SerializerFeature.PrettyFormat));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
