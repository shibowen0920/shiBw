package com.example.demo.encryption;

import cfca.sadk.algorithm.common.PKIException;
import cfca.sadk.algorithm.sm2.SM2PrivateKey;
import cfca.sadk.algorithm.sm2.SM2PublicKey;
import cfca.sadk.cgb.toolkit.SM2Toolkit;
import cfca.sadk.org.bouncycastle.util.encoders.Hex;

import java.math.BigInteger;
import java.security.KeyPair;

/**
 * 公私钥生成工具类，必须用此工具类生成才可用
 * @author shiBw
 */
public class KeyGenerator {
    public static void main(String[] args) throws PKIException {
        //生成公私钥的工具类
        KeyPair keyPair = new SM2Toolkit().SM2GenerateKeyPair();
        //获取公钥，转换16进制字符
        byte[] pub1 = keyPair.getPublic().getEncoded();
        //获取私钥，转换SM2
        SM2PrivateKey sm2PrivateKey = (SM2PrivateKey) keyPair.getPrivate();
        //转16进制
        byte[] priv1 = sm2PrivateKey.getD_Bytes();
        String hexPub = Hex.toHexString(pub1);
        String hexPriv = Hex.toHexString(priv1);

        System.out.println("公钥串：" + hexPub);
        System.out.println("私钥串：" + hexPriv);

        SM2PublicKey pub = new SM2PublicKey(Hex.decode(hexPub));
        System.out.println("----------------------------------");
        System.out.println("pub----" + pub);
        System.out.println("----------------------------------");
        SM2PrivateKey priv = new SM2PrivateKey(new BigInteger(1, Hex.decode(hexPriv)), pub.getPubX_Int(), pub.getPubYByInt());
        System.out.println("priv---" + priv);
        System.out.println("----------------------------------");
    }
}
